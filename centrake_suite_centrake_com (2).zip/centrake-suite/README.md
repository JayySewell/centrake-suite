
# @centrake/suite — 1.0.1‑alpha

**Constitution → Code.** Full constitutional suite for CENTRAKE (compiler, runtime, laws, signing, planner, CLI, site).

## Quick Start
```bash
npm install
npm run build
npm run compile
npm run dev    # open http://127.0.0.1:8080
```

## CLI
```
centrake compile <file-or-dir> --out <dir> [--manifest <dir>]
centrake plan "<intent text>" --out <file.clk>
centrake keygen <dir>
centrake sign <manifestDir> <keyDir>
centrake verify <manifestDir>
centrake pages
centrake selftest
```

## Domain + Pages
- Push to GitHub (branch `main`).  
- Enable GitHub Pages via Actions.  
- Custom domain: **centrake.com** (see CNAME file).

### DNS (registrar)
Add A records for `@` → 185.199.108.153 / .109.153 / .110.153 / .111.153  
(Optional AAAA: 2606:50c0:8000::153 / ::154 / ::155 / ::156)
