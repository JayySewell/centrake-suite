
import { Capsule } from '../clk/ast.js';
export type Law = { id: string; title: string; enforce(c: Capsule): string[] };
export const Laws: Law[] = [
  { id:'Law201', title:'Compliant Access', enforce(c){ const errs:string[]=[]; for(const op of c.flow){ if((op.kind==='engine.run'||op.kind==='engine.simulate') && (op as any).engine==='external'){ if(!c.capabilities.includes('external.access')) errs.push(`[Law201] ${c.name}: external engine requires capability 'external.access'`);} } return errs; } },
  { id:'Law205', title:'Invisible Secrets', enforce(c){ const errs:string[]=[]; for(const op of c.flow){ if(op.kind==='lens.log' && /passphrase|secret|key=/i.test(op.message)){ errs.push(`[Law205] ${c.name}: secrets must not be logged in cleartext`);} } return errs; } },
  { id:'Law215', title:'Sovereign Technology', enforce(c){ return []; } },
  { id:'Law216', title:'X-Layer Core', enforce(c){ const errs:string[]=[]; for(const op of c.flow){ if(op.kind==='layer.enter' && !c.capabilities.includes('layer.enter')) errs.push(`[Law216] ${c.name}: missing capability 'layer.enter'`);} return errs; } },
  { id:'Law219', title:'Resource Fabric', enforce(c){ return []; } },
  { id:'Law220', title:'Founder Economy', enforce(c){ return c.name?[]:[`[Law220] Capsule must have a name`]; } },
  { id:'Law221', title:'Self-Expansion Engine', enforce(c){ return []; } },
  { id:'Law222', title:'Compiler Mandate', enforce(c){ return []; } },
  { id:'Law300', title:'Anything Law', enforce(c){ return []; } },
  { id:'Law301', title:'Anything Engine', enforce(c){ return []; } },
  { id:'Law302', title:'Anything System', enforce(c){ return []; } },
  { id:'Law303', title:'NEID', enforce(c){ return []; } },
  { id:'Law304', title:'Completeness Clause', enforce(c){ return []; } },
  { id:'Law305', title:'Safety Envelope', enforce(c){ return []; } },
  { id:'Law306', title:'Identity & Signature', enforce(c){ return []; } },
  { id:'Law307', title:'Total Observability', enforce(c){ return []; } },
];
export function enforceLaws(c: Capsule, use: string[]): string[] { const chosen=Laws.filter(L=>use.some(u=>u.startsWith(L.id))); const errs:string[]=[]; for(const L of chosen) errs.push(...L.enforce(c)); return errs; }
