
export type Value = string | number | boolean | Record<string, any> | Array<any>;
export type FlowOp =
  | { kind: 'lens.log'; message: string }
  | { kind: 'layer.enter'; layer: string; params?: Record<string, any> }
  | { kind: 'engine.simulate'; engine: string; options?: Record<string, any> }
  | { kind: 'engine.run'; engine: string; options?: Record<string, any> }
  | { kind: 'unknown'; raw: string };
export type Capsule = { type:'capsule'; name:string; use:string[]; capabilities:string[]; flow:FlowOp[]; meta?:Record<string,any> };
export type Program = { capsules: Capsule[] };
