
import { Capsule, FlowOp, Program } from './ast.js';
function tokenize(input: string): string[] {
  const tokens: string[] = []; let i=0;
  const isSpace=(c:string)=>/\s/.test(c); const isIdent=(c:string)=>/[A-Za-z0-9_\.\-]/.test(c);
  while(i<input.length){ const c=input[i];
    if(isSpace(c)){i++;continue;}
    if('{}[]():,'.includes(c)){tokens.push(c);i++;continue;}
    if(c==='"'){let j=i+1,s='';while(j<input.length&&input[j]!=='"'){s+=input[j++];}tokens.push('"'+s+'"');i=j+1;continue;}
    if(c==='/'&&input[i+1]==='/'){let j=i+2;while(j<input.length&&input[j]!='\n')j++;i=j+1;continue;}
    if(isIdent(c)){let j=i,s='';while(j<input.length&&isIdent(input[j]))s+=input[j++];tokens.push(s);i=j;continue;}
    i++;
  } return tokens;
}
function expect(tokens:string[],idx:number,t:string){ if(tokens[idx]!==t) throw new Error(`Expected '${t}' got '${tokens[idx]}' @${idx}`); return idx+1; }
function parseList(tokens:string[],idx:number):[any[],number]{ idx=expect(tokens,idx,'['); const out:any[]=[];
  while(tokens[idx]!==']'){ const tk=tokens[idx]; if(tk.startsWith('"')){out.push(tk.slice(1,-1));idx++;} else {out.push(tk);idx++;} if(tokens[idx]===',') idx++; }
  idx=expect(tokens,idx,']'); return [out,idx];
}
function parseKV(tokens:string[],idx:number):[Record<string,any>,number]{ const p:Record<string,any>={}; while(true){ const k=tokens[idx]; const n=tokens[idx+1]; if(n!==':') break; idx+=2;
    let tk=tokens[idx], v:any;
    if(tk==='['){ const [arr,ni]=parseList(tokens,idx); idx=ni; v=arr; }
    else if(tk.startsWith('"')){ v=tk.slice(1,-1); idx++; }
    else if(tk==='true'||tk==='false'){ v=tk==='true'; idx++; }
    else if(/^[0-9]+(\.[0-9]+)?$/.test(tk)){ v=Number(tk); idx++; }
    else { v=tk; idx++; }
    p[k]=v; if(tokens[idx]===',') idx++;
  } return [p,idx];
}
export function parseCLK(input:string):Program{
  const tokens=tokenize(input); let idx=0; const capsules:Capsule[]=[];
  while(idx<tokens.length){ if(tokens[idx]==='capsule'){ idx++; const name=tokens[idx++]; idx=expect(tokens,idx,'{');
      const use:string[]=[]; let capabilities:string[]=[]; const flow:FlowOp[]=[];
      while(tokens[idx]!=='}'){ const key=tokens[idx++];
        if(key==='use'){ use.push(tokens[idx++]); }
        else if(key==='capabilities'){ const [arr,ni]=parseList(tokens,idx); capabilities=arr.map(String); idx=ni; }
        else if(key==='flow'){ idx=expect(tokens,idx,'{');
          while(tokens[idx]!=='}'){ const opA=tokens[idx++];
            if(opA==='lens.log'){ const m=tokens[idx++]; const msg=m.startsWith('"')?m.slice(1,-1):m; flow.push({kind:'lens.log',message:msg}); }
            else if(opA==='layer.enter'){ const layer=tokens[idx++]; let params:Record<string,any>={};
              if(!['}','lens.log','engine.simulate','engine.run','layer.enter'].includes(tokens[idx])){ const [p,ni]=parseKV(tokens,idx); params=p; idx=ni; }
              flow.push({kind:'layer.enter',layer,params}); }
            else if(opA==='engine.simulate'||opA==='engine.run'){ const engine=tokens[idx++]; let opt:Record<string,any>={};
              if(!['}','lens.log','engine.simulate','engine.run','layer.enter'].includes(tokens[idx])){ const [p,ni]=parseKV(tokens,idx); opt=p; idx=ni; }
              flow.push(opA==='engine.simulate'?{kind:'engine.simulate',engine,options:opt}:{kind:'engine.run',engine,options:opt}); }
            else { flow.push({kind:'unknown',raw:opA}); }
          } idx=expect(tokens,idx,'}');
        }
      } idx=expect(tokens,idx,'}'); capsules.push({type:'capsule',name,use,capabilities,flow}); }
    else idx++;
  } return { capsules };
}
