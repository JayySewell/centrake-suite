
import fs from 'fs'; import path from 'path'; import crypto from 'crypto';
import { parseCLK } from '../clk/parser.js'; import { emitModule } from '../compiler/codegen.js';
import { checkCapabilities } from '../compiler/passes/checks.js'; import { enforceLaws } from '../law/registry.js';
import { keygen, signDir, verifyDir } from '../security/sign.js';
function walkFiles(p:string, filter:(f:string)=>boolean){ const out:string[]=[]; if(!fs.existsSync(p)) return out; const st=fs.statSync(p);
  if(st.isDirectory()){ for(const e of fs.readdirSync(p)) out.push(...walkFiles(path.join(p,e),filter)); } else if(filter(p)) out.push(p); return out;
}
function compileFile(file:string, outDir:string, manifestDir:string){ const src=fs.readFileSync(file,'utf-8'); const prog=parseCLK(src); const outputs:string[]=[];
  for(const cap of prog.capsules){ const errs=[...checkCapabilities(cap).filter(d=>d.level==='error').map(d=>d.message), ...enforceLaws(cap, cap.use)];
    if(errs.length){ console.error('Diagnostics for', cap.name); for(const e of errs) console.error(' -', e); throw new Error('Compilation failed'); }
    const js=emitModule(cap); const rel=cap.name.replace(/\W+/g,'_').toLowerCase()+'.js'; const outPath=path.join(outDir,rel); fs.mkdirSync(outDir,{recursive:true}); fs.writeFileSync(outPath,js,'utf-8'); outputs.push(outPath);
    const manifest={ capsule:cap.name, capabilities:cap.capabilities, laws:cap.use, buildTime:new Date().toISOString(), hash:crypto.createHash('sha256').update(js).digest('hex'), lens:{truthObject:true, entries:[]} };
    fs.mkdirSync(manifestDir,{recursive:true}); const manPath=path.join(manifestDir, cap.name+'.lens.json'); fs.writeFileSync(manPath, JSON.stringify(manifest,null,2),'utf-8');
  } return outputs;
}
function preparePages(){ const outRoot=path.resolve('public'); fs.rmSync(outRoot,{recursive:true,force:true}); fs.mkdirSync(outRoot,{recursive:true});
  for(const p of ['site','dist']){ if(!fs.existsSync(p)) continue; fs.cpSync(path.resolve(p), path.join(outRoot,p), {recursive:true}); }
  if(fs.existsSync('CNAME')) fs.copyFileSync('CNAME', path.join(outRoot,'CNAME')); console.log('Built Pages at', outRoot);
}
function selftest(){ const example=path.resolve('examples/founder_sandbox.clk'); const outs=compileFile(example, path.resolve('dist/capsules'), path.resolve('dist/manifests')); console.log('Selftest outputs:', outs); }
function planIntent(intent:string, outFile:string){ const wantsImmersion=/immers|water|plasma|visual/i.test(intent); const wantsKnowledge=/know|explain|why|what|info|lens|ike/i.test(intent);
  const flows:string[]=['    lens.log "NEID: plan start"']; if(wantsImmersion){ flows.push('    layer.enter Immersion context:"PlasmaRoom" mode:"auto"','    engine.simulate "fluid" resolution:"high" interactive:true'); }
  if(wantsKnowledge){ flows.push('    engine.run ike query:"founder policy overview"'); } flows.push('    lens.log "NEID: plan end"');
  const clk=['capsule SynthFromIntent {','  use Law216.XLayer','  use Law205.InvisibleSecrets','  use Law201.CompliantAccess','  capabilities ["layer.enter","media.render"]','  flow {',...flows,'  }','}',''].join('\n');
  fs.writeFileSync(outFile,clk,'utf-8'); console.log('Planned:', outFile);
}
function usage(){ console.log(`CENTRAKE CLI
Usage:
  centrake compile <file-or-dir> --out <outDir> [--manifest <dir>]
  centrake plan "<intent text>" --out <file.clk>
  centrake keygen <dir>
  centrake sign <manifestDir> <keyDir>
  centrake verify <manifestDir> [<keyDir>]
  centrake pages
  centrake selftest`); }
async function main(){ const args=process.argv.slice(2); const cmd=args[0]; if(!cmd) return usage();
  if(cmd==='compile'){ const target=args[1]; const outDir=(args.indexOf('--out')>-1?args[args.indexOf('--out')+1]:'dist/capsules'); const manDir=(args.indexOf('--manifest')>-1?args[args.indexOf('--manifest')+1]:'dist/manifests'); if(!target) return usage();
    const files=walkFiles(target,f=>f.endsWith('.clk')); if(files.length===0 && target.endsWith('.clk')) files.push(target); if(files.length===0) throw new Error('No .clk files found');
    const allOut:string[]=[]; for(const f of files) allOut.push(...compileFile(f,outDir,manDir)); console.log('Compiled',allOut.length,'capsule(s).'); return; }
  if(cmd==='plan'){ const intent=args[1]; const outFile=(args.indexOf('--out')>-1?args[args.indexOf('--out')+1]:'examples/synth.clk'); if(!intent) return usage(); planIntent(intent,outFile); return; }
  if(cmd==='keygen'){ const dir=args[1]||'keys'; keygen(dir); console.log('Keys written to',dir); return; }
  if(cmd==='sign'){ const m=args[1]; const k=args[2]; if(!m||!k) return usage(); signDir(m,k); console.log('Signed manifests in',m); return; }
  if(cmd==='verify'){ const m=args[1]; const k=args[2]; if(!m) return usage(); const res=verifyDir(m,k); console.log('Verify results:',res); return; }
  if(cmd==='pages') return preparePages(); if(cmd==='selftest') return selftest(); return usage();
}
main().catch(err=>{ console.error(err); process.exit(1); });
