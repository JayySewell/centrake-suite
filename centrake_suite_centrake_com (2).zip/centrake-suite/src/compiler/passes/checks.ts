
import { Capsule } from '../../clk/ast.js';
export type Diagnostic = { level: 'error'|'warn'|'info', message: string };
export function checkCapabilities(c: Capsule): Diagnostic[] {
  const diags: Diagnostic[] = []; const caps = new Set(c.capabilities||[]);
  for(const op of c.flow){
    if(op.kind==='layer.enter' && !caps.has('layer.enter')) diags.push({level:'error',message:`Missing capability 'layer.enter' for ${c.name}`});
    if((op.kind==='engine.simulate'||op.kind==='engine.run') && !caps.has('media.render')) diags.push({level:'error',message:`Missing capability 'media.render' for ${c.name}`});
  }
  return diags;
}
