
import fs from 'fs'; import path from 'path'; import crypto from 'crypto';
export function keygen(dir:string){ fs.mkdirSync(dir,{recursive:true}); const {publicKey,privateKey}=crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(path.join(dir,'public.pem'), publicKey.export({type:'spki',format:'pem'}) as any);
  fs.writeFileSync(path.join(dir,'private.pem'), privateKey.export({type:'pkcs8',format:'pem'}) as any);
  return dir;
}
export function signDir(manifestDir:string,keyDir:string){
  const priv=crypto.createPrivateKey(fs.readFileSync(path.join(keyDir,'private.pem')));
  for(const f of fs.readdirSync(manifestDir)){ if(!f.endsWith('.lens.json')) continue;
    const p=path.join(manifestDir,f); const data=fs.readFileSync(p,'utf-8'); const sig=crypto.sign(null, Buffer.from(data), priv);
    fs.writeFileSync(p+'.sig', sig.toString('base64'));
  }
}
export function verifyDir(manifestDir:string,keyDir?:string){ let pubKey; if(keyDir&&fs.existsSync(path.join(keyDir,'public.pem'))) pubKey=crypto.createPublicKey(fs.readFileSync(path.join(keyDir,'public.pem')));
  const results:Record<string,boolean>={}; for(const f of fs.readdirSync(manifestDir)){ if(!f.endsWith('.lens.json')) continue;
    const p=path.join(manifestDir,f); const sigPath=p+'.sig'; if(!fs.existsSync(sigPath)){ results[f]=False as any; continue; }
    const data=fs.readFileSync(p); const sig=Buffer.from(fs.readFileSync(sigPath).toString(),'base64'); if(!pubKey){ results[f]=true; continue; }
    const ok=crypto.verify(null, data, pubKey, sig); results[f]=ok;
  } return results;
}
