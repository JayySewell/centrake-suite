Law registry summary and enforcement notes.
