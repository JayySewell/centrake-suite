CLK v1 textual language draft and examples.
